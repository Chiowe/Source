1.drpy_gao整个文件夹丢到zy服务的根目录
2.zy设置数据导入hipy源输入下面的地址:
http://127.0.0.1:9978/api/v1/file/drpy_gao/js.json